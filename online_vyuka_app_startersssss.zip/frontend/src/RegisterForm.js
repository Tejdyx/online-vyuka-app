
import React, { useState } from 'react';

function RegisterForm() {
  const [form, setForm] = useState({ email: '', password: '', name: '', role: 'student', language_preference: 'cs' });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    const response = await fetch('/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    });
    const data = await response.json();
    alert(data.id ? 'Registration successful!' : 'Registration failed.');
  };

  return (
    <form onSubmit={handleRegister}>
      <h2>Register</h2>
      <input name="email" type="email" placeholder="Email" onChange={handleChange} />
      <input name="password" type="password" placeholder="Password" onChange={handleChange} />
      <input name="name" placeholder="Name" onChange={handleChange} />
      <select name="role" onChange={handleChange}>
        <option value="student">Student</option>
        <option value="teacher">Teacher</option>
      </select>
      <select name="language_preference" onChange={handleChange}>
        <option value="cs">Čeština</option>
        <option value="en">English</option>
      </select>
      <button type="submit">Register</button>
    </form>
  );
}

export default RegisterForm;
