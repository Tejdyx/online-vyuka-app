
import React from 'react';
import { useTranslation } from 'react-i18next';
import LoginForm from './LoginForm';
import RegisterForm from './RegisterForm';

function App() {
  const { i18n } = useTranslation();

  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng);
  };

  return (
    <div>
      <h1>Online Výuka</h1>
      <button onClick={() => changeLanguage('cs')}>Čeština</button>
      <button onClick={() => changeLanguage('en')}>English</button>
      <LoginForm />
      <RegisterForm />
    </div>
  );
}

export default App;
