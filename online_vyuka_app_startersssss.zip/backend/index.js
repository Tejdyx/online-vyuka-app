
const express = require('express');
const app = express();
const PORT = process.env.PORT || 3001;
const authRoutes = require('./routes');

app.use(express.json());
app.use('/api', authRoutes);

app.get('/', (req, res) => {
  res.send('Online Vyuka API is running.');
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
