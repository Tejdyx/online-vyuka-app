
const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const router = express.Router();
const pool = require('./db');

router.post('/register', async (req, res) => {
  const { email, password, role, name, language_preference } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  try {
    const result = await pool.query(
      'INSERT INTO users (email, password_hash, role, name, language_preference, created_at) VALUES ($1, $2, $3, $4, $5, NOW()) RETURNING *',
      [email, hashedPassword, role, name, language_preference]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'User registration failed' });
  }
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
  const user = result.rows[0];
  if (user && await bcrypt.compare(password, user.password_hash)) {
    const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET || 'secretkey');
    res.json({ token });
  } else {
    res.status(403).json({ error: 'Invalid credentials' });
  }
});

module.exports = router;
